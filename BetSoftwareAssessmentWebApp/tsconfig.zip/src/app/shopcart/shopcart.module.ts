import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShopCartService } from './shopcart.service'



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ShopCartService
  ]
})
export class ShopcardModule { }
